var donors = {
  
  donors30: [1, 10, 3],

  donors25: [2, 4, 6],

  donors20: [1, 3, 4, 6]

}